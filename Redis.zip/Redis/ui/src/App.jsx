import React, { useState, useRef, useEffect } from 'react';
import './App.css';
import axios from 'axios';
import Playlist from './components/Playlist/Playlist';
import PlaylistInfo from './components/PlaylistInfo/PlaylistInfo';
import Song from './components/Song/Song';

function App() {
  const inputRef = useRef(null);
  const [name, setName] = useState(null);
  const [playlists, setPlaylists] = useState([]);
  const [selectedPlaylistId, setSelectedPlaylistId] = useState(null);
  const [update, setUpdate] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get('http://127.0.0.1:8000/get_all_playlists/');
        setPlaylists(response.data.playlists);
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    fetchData();

    
    // Set up an interval to fetch data every 300ms
    const intervalId = setInterval(() => {
      fetchData();
    }, 300);

    // Clean up the interval when the component is unmounted or when the update state changes
    return () => clearInterval(intervalId);
  }, [update]);

  const handleLogin = () => {
    const inputValue = inputRef.current.value;
    setName(inputValue);
  };

  const handleCreatePlaylist = async () => {
    try {
      const playlistName = inputRef.current.value;
  
      // Proveri da li je uneto ime plejliste
      if (!playlistName) {
        console.error('Please enter a playlist name.');
        return;
      }
  
      // Posalji zahtev za kreiranje plejliste na Django API
      await axios.get(`http://127.0.0.1:8000/create_playlist/${name}/${playlistName}/`);
  
      // Osveži listu plejlista nakon kreiranja nove
      const response = await axios.get('http://127.0.0.1:8000/get_all_playlists/');
      setPlaylists(response.data.playlists);

    } catch (error) {
      console.error('Error creating playlist:', error);
    }
  };

  const handlePlaylistClick = (playlistId) => {
    console.log('Playlist clicked:', playlistId);
    // Postavi selectedPlaylistId na playlistId kako bi prikazao PlaylistInfo komponentu
    setSelectedPlaylistId(playlistId);
  };

  const updatePlaylists = () => {
    setUpdate(!update);
  }


  return (
    <>
      {/* Prikaži formu za unos imena samo ako name nije definisan */}
      {!name ? (
        <div className='login-div'>
          <div className='login-div-input'>
            <p>Name</p>
            <input type='text' placeholder='Enter name' ref={inputRef} />
          </div>
          <button onClick={handleLogin}>Login</button>
        </div>
      ) : (
        // Prikaži trenutno ime ako je name definisan
        <>
          <p>Name: {name}</p>
          <div className='list'>
          {selectedPlaylistId ? (
        // Ako je odabrana plejlista, prikaži PlaylistInfo
        <PlaylistInfo playlistId={selectedPlaylistId} isOwner={playlists.find(playlist => playlist.id === selectedPlaylistId).owner === name} />
      ) : (
        // Inače, prikaži listu plejlista
        <div className='playlist-list'>
          {playlists.map((playlist) => (
            <Playlist
              key={playlist.id}
              updatePlaylists={updatePlaylists}
              {...playlist}
              isOwner={playlist.owner === name ? true : false}
              onClick={() => handlePlaylistClick(playlist.id)} // Dodato rukovanje klikom na plejlistu
            />
          ))}
        </div>
      )}
          </div>
          <div className='form'>
            <input className='input-create' type='text' placeholder='Playlist name' ref={inputRef}/>
            <button onClick={handleCreatePlaylist} className='button-create'>Create playlist</button>
          </div>
        </>
      )}
    </>
  );
}

export default App;
