import React, { useState, useRef, useEffect } from 'react';
import './PlaylistInfo.css';
import axios from 'axios';
import Song from '../Song/Song';

const PlaylistInfo = ({ playlistId, isOwner }) => {
    const [songs, setSongs] = useState([]);
    const [allSongs, setAllSongs] = useState([]);
  
    useEffect(() => {
      const fetchSongs = async () => {
        try {
          const response = await axios.get(`http://127.0.0.1:8000/get_playlist_info/${playlistId}/`);
          setSongs(response.data.playlist.songs);
        } catch (error) {
          console.error('Error fetching songs:', error);
        }
      };
  
      fetchSongs();

      // Set up an interval to fetch data every 300ms
    const intervalId = setInterval(() => {
        fetchSongs();
      }, 300);
  
      // Clean up the interval when the component is unmounted or when the update state changes
      return () => clearInterval(intervalId);
    }, [playlistId]);
  
    useEffect(() => {
      const fetchAllSongs = async () => {
        try {
          const response = await axios.get('http://127.0.0.1:8000/get_all_songs/');
          setAllSongs(response.data.songs);
        } catch (error) {
          console.error('Error fetching all songs:', error);
        }
      };
  
      if (isOwner) {
        fetchAllSongs();
      }
    }, [isOwner]);
  
    const handleToggleSong = async (songId, isListed) => {
      try {
        if (isListed) {
          // Ako je pesma već na plejlisti, pozovi API za uklanjanje pesme
          await axios.get(`http://127.0.0.1:8000/remove_song_from_playlist/${playlistId}/${songId}/`);
        } else {
          // Ako pesma nije na plejlisti, pozovi API za dodavanje pesme
          await axios.get(`http://127.0.0.1:8000/add_song_to_playlist/${playlistId}/${songId}/`);
        }
  
        // Osveži listu pesama nakon promene
        const response = await axios.get(`http://127.0.0.1:8000/get_playlist_info/${playlistId}/`);
        setSongs(response.data.playlist.songs);
      } catch (error) {
        console.error('Error handling toggle song:', error);
      }
    };
  
    const filteredSongs = isOwner
      ? allSongs.filter((song) => !songs.some((existingSong) => existingSong.id === song.id))
      : songs;

    
  
    return (
      <>
        <div className='songs-list'>
          {songs.map((song) => (
            <Song
              key={song.id}
              isListed={true}
              isOwner={isOwner}
              playlistId={playlistId}
              songId={song.id}
              updatePlaylist={() => handleToggleSong(song.id, true)}
              artist={song.artist_name}
              title={song.song_name}
            />
          ))}
        </div>
        {isOwner && (
          <div className='songs-list'>
            <h4>All Songs</h4>
            {filteredSongs.map((song) => (
              <Song
                key={song.id}
                isListed={false}
                isOwner={isOwner}
                playlistId={playlistId}
                songId={song.id}
                updatePlaylist={() => handleToggleSong(song.id, false)}
                artist={song.artist_name}
                title={song.song_name}
              />
            ))}
          </div>
        )}
      </>
    );
  };
  
  export default PlaylistInfo;

