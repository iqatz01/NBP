import React from 'react';
import './Song.css';

function Song({ title, artist, isListed, isOwner, playlistId, songId, updatePlaylist }) {
    const handleButtonClick = async () => {
        try {
          // Pozovi funkciju za dodavanje/uklanjanje pesme iz plejliste
          updatePlaylist();
        } catch (error) {
          console.error('Error handling button click:', error);
        }
      };

  return (
    <div className='song' style={{ backgroundColor: isListed ? 'rgba(50, 255, 200, 0.5)' : 'rgba(135, 250, 137, 0.5)'}}>
      <h2>{title}</h2>
      <div className='right-div'>
        <h2>{artist}</h2>
        {isOwner && (
          <button
            style={{ marginTop: 5, width: 60, height: '80%' }}
            onClick={handleButtonClick}
          >
            {isListed ? 'Remove' : 'Add'}
          </button>
        )}
      </div>
    </div>
  );
}

export default Song;
