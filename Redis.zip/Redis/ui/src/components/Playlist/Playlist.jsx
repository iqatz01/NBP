import React, { useState, useRef } from 'react';
import './Playlist.css';
import axios from 'axios';
import PlaylistInfo from '../PlaylistInfo/PlaylistInfo';

const Playlist = ({ id, name, owner, created_at, rating, isOwner, updatePlaylists }) => {

  const [showInfo, setShowInfo] = useState(false);

  const handleClick = () => {
    console.log('Playlist clicked within Playlist component:', id);
    setShowInfo(!showInfo);
  };

  const handleDelete = async (event) => {
    event.stopPropagation();
    console.log(id);
    try {
      
        await axios.get(`http://127.0.0.1:8000/delete_playlist/${parseInt(id)}/`);

        updatePlaylists();
        // Osveži listu pesama nakon promene
        const response = await axios.get(`http://127.0.0.1:8000/get_all_playlists/`);
    } catch (error) {
      console.error('Error handling delete playlist:', error);
    }
  }

  const handleVote = async (event) => {
    event.stopPropagation();
    try {
      await axios.get(`http://127.0.0.1:8000/vote_for_playlist/${id}/`);

      updatePlaylists();
      // Osveži listu pesama nakon promene
      const response = await axios.get(`http://127.0.0.1:8000/get_all_playlists/`);
    } catch (error) {
    console.error('Error handling delete playlist:', error);
    }
  }

  return (
    <>
    <div className={`playlist ${isOwner ? 'owner-playlist' : 'non-owner-playlist'}`} key={id} onClick={handleClick}>
      <h2>{name}</h2>
      <div className='right-division'>
        <div className='right'>
          <a>Owner: {owner}</a>
          <a>Created: {created_at}</a>
          <a>Rating: {rating}</a>
        </div>
        <div>
          <button onClick={isOwner ? handleDelete : handleVote} className={ isOwner ? 'btn delete' : 'btn vote'}>{ isOwner ? 'Delete' : 'Vote'}</button>
        </div>
      </div>
     
    </div>
    { showInfo ? <PlaylistInfo playlistId={id} isOwner={isOwner} /> : null }
    </>
  );
};

export default Playlist;

