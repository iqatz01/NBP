"""
URL configuration for redisdjangoproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.urls import path, include
from redisdjangoapp.views import (
    add_song_to_playlist,
    remove_song_from_playlist,
    vote_for_playlist,
    create_playlist,
    delete_playlist,
    get_all_playlists,
    add_song_to_list,
    get_all_songs,
    get_playlist_info
)

from redisdjangoapp.routing import websocket_urlpatterns

urlpatterns = [
    path('add_song_to_playlist/<int:playlist_id>/<int:song_id>/', add_song_to_playlist, name='add_song_to_playlist'),
    path('remove_song_from_playlist/<int:playlist_id>/<int:song_id>/', remove_song_from_playlist, name='remove_song_from_playlist'),
    path('vote_for_playlist/<int:playlist_id>/', vote_for_playlist, name='vote_for_playlist'),
    path('create_playlist/<str:owner>/<str:playlist_name>/', create_playlist, name='create_playlist'),
    path('delete_playlist/<int:playlist_id>/', delete_playlist, name='delete_playlist'),
    path('get_all_playlists/', get_all_playlists, name='get_all_playlists'),
    path('add_song_to_list/<str:artist_name>/<str:song_name>/', add_song_to_list, name='add_song_to_list'),
    path('get_all_songs/', get_all_songs, name='get_all_songs'),
    path('get_playlist_info/<int:playlist_id>/', get_playlist_info, name='get_playlist_info'),
    path('ws/', include(websocket_urlpatterns)),

]
