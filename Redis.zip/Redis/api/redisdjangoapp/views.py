from django.http import JsonResponse
from django_redis import get_redis_connection
import json


def add_song_to_playlist(request, playlist_id, song_id):
    redis_conn = get_redis_connection("default")

    # Dodaj pesmu u set plejliste
    redis_conn.sadd(f"playlist_songs:{playlist_id}", int(song_id))

    return JsonResponse({'status': 'success', 'message': 'Song added to playlist'})

def remove_song_from_playlist(request, playlist_id, song_id):
    redis_conn = get_redis_connection("default")

    # Ukloni pesmu iz set plejliste
    redis_conn.srem(f"playlist_songs:{playlist_id}", song_id)

    return JsonResponse({'status': 'success', 'message': 'Song removed from playlist'})

def vote_for_playlist(request, playlist_id):
    redis_conn = get_redis_connection("default")

    # Incrementuj ocenu pesme u hash mapi plejliste
    redis_conn.hincrby(f"playlist:{playlist_id}", 'rating', 1)

    return JsonResponse({'status': 'success', 'message': 'Vote recorded'})

def create_playlist(request, owner, playlist_name):
    redis_conn = get_redis_connection("default")

    # Generiši novi identifikator plejliste
    new_playlist_id = redis_conn.incr('playlist_counter')

    # Kreiraj hash mapu za novu plejlistu
    redis_conn.hmset(f"playlist:{new_playlist_id}", {
        'name': playlist_name,
        'owner': owner,
        'created_at': '2023-02-01',
        'rating': 0,
    })

    # Dodaj plejlistu u set svih plejlista
    redis_conn.sadd('all_playlists', new_playlist_id)

    return JsonResponse({'status': 'success', 'message': 'Playlist created'})

def delete_playlist(request, playlist_id):
    redis_conn = get_redis_connection("default")

    # Obriši hash mapu i set za plejlistu
    redis_conn.delete(f"playlist:{playlist_id}")
    redis_conn.srem('all_playlists', playlist_id)

    return JsonResponse({'status': 'success', 'message': 'Playlist deleted'})

def get_all_playlists(request):
    redis_conn = get_redis_connection("default")

    # Dobavi sve identifikatore plejlista iz set-a
    playlist_ids = redis_conn.smembers('all_playlists')

    # Inicijalizuj listu za čuvanje informacija o plejlistama
    playlists = []

    # Dobavi informacije o svakoj plejlisti iz hash mapa
    for playlist_id in playlist_ids:
        playlist_info = redis_conn.hgetall(f"playlist:{playlist_id.decode('utf-8')}")
        playlists.append({
            'id': playlist_id.decode('utf-8'),
            'name': playlist_info.get(b'name').decode('utf-8'),
            'owner': playlist_info.get(b'owner').decode('utf-8'),
            'created_at': playlist_info.get(b'created_at').decode('utf-8'),
            'rating': float(playlist_info.get(b'rating', 0)),
        })

    return JsonResponse({'playlists': playlists})

def add_song_to_list(request, artist_name, song_name):
    redis_conn = get_redis_connection("default")

    # Generiši novi identifikator za pesmu
    new_song_id = redis_conn.incr('song_counter')

    # Dodaj pesmu u globalnu listu pesama
    redis_conn.rpush('songs', new_song_id)

    # Kreiraj hash mapu za novu pesmu
    redis_conn.hmset(f"song:{new_song_id}", {
        'artist_name': artist_name,
        'song_name': song_name,
    })

    return JsonResponse({'status': 'success', 'message': 'Song added to list'})
    
def get_all_songs(request):
    redis_conn = get_redis_connection("default")

    # Dobavi sve identifikatore pesama iz globalne liste
    song_ids = redis_conn.lrange('songs', 0, -1)

    # Inicijalizuj listu za čuvanje informacija o pesmama
    songs = []

    # Dobavi informacije o svakoj pesmi iz hash mapa
    for song_id in song_ids:
        song_info = redis_conn.hgetall(f"song:{song_id.decode('utf-8')}")
        songs.append({
            'id': song_id.decode('utf-8'),
            'artist_name': song_info.get(b'artist_name').decode('utf-8'),
            'song_name': song_info.get(b'song_name').decode('utf-8'),
        })

    return JsonResponse({'songs': songs})

def get_playlist_info(request, playlist_id):
    redis_conn = get_redis_connection("default")

    # Proveri da li plejlista sa zadatim id postoji
    if not redis_conn.sismember('all_playlists', playlist_id):
        return JsonResponse({'error': 'Playlist not found'}, status=404)

    # Dobavi informacije o plejlisti iz hash mape
    playlist_info = redis_conn.hgetall(f"playlist:{playlist_id}")

    # Dohvati identifikatore pesama iz seta povezanog s plejlistom
    playlist_song_ids = redis_conn.smembers(f"playlist_songs:{playlist_id}")

    # Inicijalizuj listu za čuvanje informacija o pesmama u plejlisti
    playlist_songs = []

    # Dobavi informacije o svakoj pesmi iz hash mapa
    for song_id in playlist_song_ids:
        song_id = int(song_id)  # Konvertuj ID pesme u integer
        song_info = redis_conn.hgetall(f"song:{song_id}")
        artist_name = song_info.get(b'artist_name')
        song_name = song_info.get(b'song_name')

        # Dodaj debug ispis kako bismo videli informacije o pesmi
        print(f"Song ID: {song_id}, Artist: {artist_name}, Song Name: {song_name}")

        # Proveri da li ključevi postoje u hash mapi
        if artist_name and song_name:
            playlist_songs.append({
                'id': str(song_id),
                'artist_name': artist_name.decode('utf-8'),
                'song_name': song_name.decode('utf-8'),
            })

    # Sastavi odgovor sa informacijama o plejlisti i listom pesama
    playlist_data = {
        'id': str(playlist_id),
        'name': playlist_info.get(b'name').decode('utf-8'),
        'owner': playlist_info.get(b'owner').decode('utf-8'),
        'created_at': playlist_info.get(b'created_at').decode('utf-8'),
        'rating': float(playlist_info.get(b'rating', 0)),
        'songs': playlist_songs,
    }

    return JsonResponse({'playlist': playlist_data})

def notify_frontend_change(change_type, playlist_id):
    redis_conn = get_redis_connection("default")
    channel_name = "frontend_updates"

    # Kreirajte JSON objekat sa informacijama o promeni
    message = {
        'change_type': change_type,
        'playlist_id': playlist_id,
    }

    # Objekat šaljemo u JSON formatu
    redis_conn.publish(channel_name, json.dumps(message))