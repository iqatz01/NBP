"""
URL configuration for fitness_api project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

from django.urls import path
from nbp_mongo import functions

urlpatterns = [
    path("registerUser/", functions.registerUser),
    path("authenticateUser/", functions.authenticateUser),
    path("getUserDetails/<str:user_id>/", functions.getUserDetails),
    path("deleteUser/", functions.deleteUser),
    path("setOptionalUserDetails/", functions.setOptionalUserDetails),
    path("addDailyActivity/", functions.addDailyActivity),
    path("updateDailyActivity/", functions.updateDailyActivity),
    path("deleteDailyActivity/", functions.deleteDailyActivity),
    path("getActivitiesAboveStepCount/<str:user_details_id>/<int:step_count_threshold>/", functions.getActivitiesAboveStepCount),
    path("getActivitiesAboveStepCount/<str:user_details_id>/<int:step_count_threshold>/<int:offset>/", functions.getActivitiesAboveStepCount),
    path("getActivitiesAboveStepCount/<str:user_details_id>/<int:step_count_threshold>/<int:offset>/<int:limit>/", functions.getActivitiesAboveStepCount),
    path("top3WaterConsumers/<str:city>/", functions.top3WaterConsumers),
    path("addFitPass/", functions.addFitPass),
    path("getHealthTips/<str:user_id>/", functions.getHealthTips),
    path("getUserActivities/<str:user_details_id>/", functions.getUserActivities),
    path("getActivityById/<str:activity_id>/", functions.getActivityById),
]
