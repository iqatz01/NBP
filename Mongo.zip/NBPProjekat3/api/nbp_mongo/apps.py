from django.apps import AppConfig


class NbpMongoConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'nbp_mongo'
