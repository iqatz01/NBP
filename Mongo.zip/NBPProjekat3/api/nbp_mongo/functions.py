from django.http import JsonResponse
from django.views.decorators.http import require_GET, require_POST, require_http_methods
from pymongo import MongoClient, ASCENDING, DESCENDING
from datetime import datetime, timedelta
import datetime as dt

import json
import bcrypt
from bson import ObjectId

connection_string = 'mongodb://localhost:27017/'
client = MongoClient(connection_string)

db = client['db_nbp']
auth_collection = db['auth']
users_collection = db['users']
activities_collection = db['activities']

auth_collection.create_index([('username', ASCENDING)], unique=True)
activities_collection.create_index([('step_count', DESCENDING)])
users_collection.create_index([('address.city', 1)])

def require_DELETE(function):
    return require_http_methods(['DELETE'])(function)

def require_PATCH(function):
    return require_http_methods(['PATCH'])(function)

def is_valid_integer(value):
            try:
                int(value)
                return True
            except ValueError:
                return False
    
def is_valid_string(value):
    return isinstance(value, str) and value[0].isalpha()

@require_DELETE
def deleteDailyActivity(request):
    try:
        activity_id = json.loads(request.body).get('activity_id')
        delete_activity_result = activities_collection.delete_one({'_id': ObjectId(activity_id)})

        if delete_activity_result.deleted_count == 1:
            user_id = json.loads(request.body).get('user_id')

            users_collection.update_one(
                {'_id': ObjectId(user_id)},
                {'$pull': {'activity_list': {'activity_id': activity_id}}},
            )

            response_data = {'status': 'Activity deleted successfully.'}
            return JsonResponse(response_data)
        else:
            return JsonResponse({'status': 'Error', 'message': 'Activity not found'}, status=404)

    except Exception as e:
        return JsonResponse({'status': 'Error', 'error_message': str(e)}, status=500)


@require_PATCH
def updateDailyActivity(request):
    try:
        data = json.loads(request.body)
    
        if not all(is_valid_integer(value) for key, value in data.items() if key != 'activity_id'):
            return JsonResponse({'status': 'Error', 'message': 'Invalid input. All values must be integers.'}, status=400)

        update_values = {}
    
        for key, value in data.items():
            if key != 'activity_id':
                update_values[key] = int(value)

        activities_collection.update_one(
            {'_id': ObjectId(data.get('activity_id'))},
            {'$set': update_values},
        )

        response_data = {'status': 'Daily activity updated successfully.'}
        return JsonResponse(response_data)
    
    except Exception as e:
        return JsonResponse({'status': 'Error', 'error_message': str(e)}, status=500)


@require_POST
def addDailyActivity(request):
    try:
        data = json.loads(request.body)

        if not all(is_valid_integer(data.get(key)) for key in ['water', 'food', 'strength', 'cardio', 'step']):
            return JsonResponse({'status': 'Error', 'message': 'Invalid input. All values must be integers.'}, status=400)

        new_activity = {
            'user_details_id': data.get('user_details_id'),
            'date': str(dt.date.today()),
            'water_in_ml': data.get('water'),
            'food_in_kcal': data.get('food'),
            'strength_training_in_min': data.get('strength'),
            'cardio_training_in_min': data.get('cardio'),
            'step_count': data.get('step'),
        }

        add_new_activity_result = activities_collection.insert_one(new_activity)

        if add_new_activity_result.inserted_id:
            users_collection.update_one(
                {'_id': ObjectId(data.get('user_details_id'))},
                {
                    '$push': {
                        'activity_list': {
                            'date': new_activity['date'],
                            'activity_id': str(add_new_activity_result.inserted_id),
                        }
                    },
                    '$set': {
                        'last_added_activity': new_activity
                    }
                },
            )

            response_data = {'status': 'Activity added successfully.'}
            return JsonResponse(response_data)
        else:
            return JsonResponse({'status': 'Error', 'message': 'Failed to add activity.'}, status=500)
    
    except Exception as e:
        return JsonResponse({'status': 'Error', 'error_message': str(e)}, status=500)

@require_POST
def setOptionalUserDetails(request):
    try:
        data = json.loads(request.body)

        body_data = {}

        if 'weight' in data and is_valid_integer(data['weight']):
            body_data['weight'] = int(data['weight'])

        if 'height' in data and is_valid_integer(data['height']):
            body_data['height'] = int(data['height'])

        if 'address' in data and isinstance(data['address'], dict):
            body_data['address'] = data['address']

        if body_data:
            existing_user_data = users_collection.find_one({'_id': ObjectId(data.get('user_details_id'))})

            if existing_user_data:
                users_collection.update_one(
                    {'_id': ObjectId(data.get('user_details_id'))},
                    {'$set': body_data},
                )

            return JsonResponse({'status': 'Optional user details updated successfully.'})

    except json.JSONDecodeError:
        return JsonResponse({'status': 'Error!', 'error': 'Wrong JSON format!'})
    except Exception as e:
        return JsonResponse({'status': 'Error', 'error_message': str(e)})

@require_GET
def getUserDetails(request, user_id):
    try:
        user_data = users_collection.find_one({'_id': ObjectId(user_id)})

        if user_data:
            response_data = {
                'name': user_data['name'],
                'age': user_data['age']
            }

            # Provera da li postoji svaki od propertija pre dodavanja u response_data
            if 'height' in user_data:
                response_data['height'] = user_data['height']
            if 'weight' in user_data:
                response_data['weight'] = user_data['weight']
            if 'address' in user_data:
                response_data['address'] = user_data['address']
            if 'fit_pass' in user_data:
                response_data['fit_pass'] = user_data['fit_pass']
            if 'reg_datetime' in user_data:
                response_data['reg_datetime'] = user_data['reg_datetime']
            response_data['user_details_id'] = user_id

            return JsonResponse(response_data)
        else:
            return JsonResponse({'status': 'Error', 'message': 'User not found'}, status=404)
    
    except Exception as e:
        return JsonResponse({'status': 'Error', 'error_message': str(e)})
    
@require_POST
def authenticateUser(request):
    try:
        data = json.loads(request.body)

        username = data.get('username')
        password = data.get('password')

        user_auth = auth_collection.find_one({'username': username})
        
        if user_auth and bcrypt.checkpw(password.encode('utf-8'), user_auth['password'].encode('utf-8')):
            return JsonResponse({'status': 'success', 'user_details_id': user_auth['user_details_id']})
        else:
            return JsonResponse({'status': 'error', 'message': 'Login failed. Wrong credentials.'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})

@require_POST
def registerUser(request):
    try:
        data = json.loads(request.body)

        if 'username' in data and not is_valid_string(data['username']):
            return JsonResponse({'status': 'Error', 'message': 'Invalid username. Username must be a string and start with a letter.'}, status=400)


        existing_user = auth_collection.find_one({'username': data.get('username')})
        if existing_user:
            return JsonResponse({'status': 'Error!', 'error': 'Username already exists.'})

        new_user = {
            'name': data.get('name'),
            'age': data.get('age'),
            'reg_datetime': datetime.now()
        }

        reg_user_result = users_collection.insert_one(new_user)

        if reg_user_result.inserted_id:
            hashed_password = bcrypt.hashpw(data.get('password').encode('utf-8'), bcrypt.gensalt())

            new_auth = {
                'user_details_id': str(reg_user_result.inserted_id),
                'username': data.get('username'),
                'password': hashed_password.decode('utf-8')
            }

            auth_collection.insert_one(new_auth)

            return JsonResponse({'status': 'User registered successfully.'})
        else:
            return JsonResponse({'status': 'Error!', 'error': 'User registration failed.'})

    except json.JSONDecodeError:
        return JsonResponse({'status': 'Error!', 'error': 'Wrong JSON format!'})
    except Exception as e:
        return JsonResponse({'status': 'Error!', 'error': str(e)})


@require_DELETE
def deleteUser(request):
    try:
        data = json.loads(request.body)

        username = data.get('username')
        password = data.get('password')

        user_auth = auth_collection.find_one({'username': username})
        
        if user_auth and bcrypt.checkpw(password.encode('utf-8'), user_auth['password'].encode('utf-8')):
            delete_user_details_result = users_collection.delete_one({'_id': ObjectId(user_auth['user_details_id'])})

            if delete_user_details_result.deleted_count == 1:
                delete_auth_result = auth_collection.delete_one({'_id': ObjectId(user_auth['_id'])})

                if delete_auth_result.deleted_count == 1:
                    return JsonResponse({'status': 'Success', 'message': 'User deleted successfully.'})
        else:
            return JsonResponse({'status': 'Error', 'message': 'Authentication failed! User deletion unsuccessful.'})
    except Exception as e:
        return JsonResponse({'status': 'error', 'message': str(e)})

@require_GET
def getUserActivities(request, user_details_id):
    try:
        user_data = users_collection.find_one({'_id': ObjectId(user_details_id)})

        if user_data:
            activity_list = user_data.get('activity_list', [])
            response_data = {'status': 'Success', 'activity_list': activity_list}
            return JsonResponse(response_data)
        else:
            return JsonResponse({'status': 'Error', 'message': 'User not found'}, status=404)

    except Exception as e:
        return JsonResponse({'status': 'Error', 'error_message': str(e)}, status=500)

@require_GET
def getActivitiesAboveStepCount(request, user_details_id, step_count_threshold, offset=0, limit=3):
    try:
        limit = max(1, limit)
        limit = min(5, limit)
        step_count_threshold = int(step_count_threshold)

        pipeline = [
            {
                '$match': {
                    'user_details_id': user_details_id,
                    'step_count': {'$gt': step_count_threshold}
                }
            },
            {
                '$sort': {
                    'date': -1
                }
            },
            {
                '$skip': offset 
            },
            {
                '$limit': limit 
            },
            {
                '$project': {
                    '_id': 0, 
                    'date': 1,
                    'step_count': 1
                }
            }
        ]

        result = list(activities_collection.aggregate(pipeline))

        response_data = {'status': 'Success', 'activities': result}
        return JsonResponse(response_data)

    except ValueError:
        return JsonResponse({'status': 'Error', 'message': 'Invalid step_count_threshold parameter.'}, status=400)
    except Exception as e:
        return JsonResponse({'status': 'Error', 'error_message': str(e)}, status=500)
    
@require_GET
def top3WaterConsumers(request, city):
    try:
        pipeline = [
            {
                '$match': {
                    'last_added_activity': {'$exists': True},
                    'last_added_activity.water_in_ml': {'$exists': True},
                    'address.city': city
                }
            },
            {
                '$sort': {
                    'last_added_activity.water_in_ml': -1
                }
            },
            {
                '$limit': 3
            },
            {
                '$project': {
                    '_id': 0,
                    'name': '$name',
                    'water_consumpted': '$last_added_activity.water_in_ml'
                }
            }
        ]

        result = list(users_collection.aggregate(pipeline))

        return JsonResponse({'status': 'Success', 'data': result})

    except Exception as e:
        return JsonResponse({'status': 'Error', 'error_message': str(e)}, status=500)
    
@require_POST
def addFitPass(request):
    try:
        data = json.loads(request.body)
        user_id = data.get('user_id')

        fit_pass_value = datetime.now() + timedelta(days=30)

        users_collection.update_one(
            {'_id': ObjectId(user_id)},
            {'$set': {'fit_pass': fit_pass_value}}
        )

        return JsonResponse({'status': 'Success', 'message': 'Fit pass added successfully.'})

    except Exception as e:
        return JsonResponse({'status': 'Error', 'error_message': str(e)}, status=500)
    
@require_GET
def getHealthTips(request, user_id):
    try:
        user_data = users_collection.find_one({'_id': ObjectId(user_id)})

        if not user_data:
            return JsonResponse({'status': 'Error', 'message': 'User not found'}, status=404)

        last_activity = user_data.get('last_added_activity', {})

        water_in_ml = last_activity.get('water_in_ml', 0)
        step_count = last_activity.get('step_count', 0)
        food_in_kcal = last_activity.get('food_in_kcal', 0)
        cardio_training_in_min = last_activity.get('cardio_training_in_min', 0)
        strength_training_in_min = last_activity.get('strength_training_in_min', 0)

        tips = []

        if water_in_ml < 1000:
            tips.append(f'You should drink more water. Current: {water_in_ml}ml, expected: 1000ml')

        if step_count < 7000:
            tips.append('Move more.')

        if food_in_kcal < 1500:
            tips.append('Increase food intake to maintain current weight. You are currently in a calorie deficit.')
        elif food_in_kcal > 2500:
            tips.append('Decrease food intake to maintain current weight. You are currently in a calorie surplus.')

        total_training_minutes = cardio_training_in_min + strength_training_in_min
        if total_training_minutes < 30:
            tips.append('Train more.')

        response_data = {'status': 'Success', 'tips': tips}
        return JsonResponse(response_data)

    except Exception as e:
        return JsonResponse({'status': 'Error', 'error_message': str(e)}, status=500)
    
@require_GET
def getActivityById(request, activity_id):
    try:
        activity = activities_collection.find_one({'_id': ObjectId(activity_id)})
        if activity:
            activity['_id'] = str(activity['_id'])  # Pretvaranje ObjectId u string
            return JsonResponse({'status': 'Success', 'activity': activity})
        else:
            return JsonResponse({'status': 'Error', 'message': 'Activity not found'}, status=404)
    except Exception as e:
        return JsonResponse({'status': 'Error', 'error_message': str(e)}, status=500)