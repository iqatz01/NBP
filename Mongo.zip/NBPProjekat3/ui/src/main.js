import { createApp } from 'vue'
import './style.css'
import App from './App.vue'
import { createRouter, createWebHistory } from 'vue-router'
import Auth from './components/Auth.vue'
import Home from './components/Home.vue'

const router = createRouter({
    history: createWebHistory(),
    routes: [
      { path: '/login', component: Auth, name: 'Login' },
      { path: '/register', component: Auth, name: 'Register' },
      { path: '/home', component: Home, name: 'Home' },
      { path: '/', redirect: '/login' }
    ]
  })
  
  createApp(App).use(router).mount('#app')
