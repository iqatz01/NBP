<script setup>
import axios from 'axios'
import { ref } from 'vue'

defineProps({
  userDetailsData: Object,
})

const healthTips = ref([]);
const top3WaterConsumers = ref([]);
const city = ref('')
const productiveActivities = ref([])
const offset = ref(0)
const limit = ref(3)
const showActivityForm = ref(false);
const newActivity = ref({
  water: null,
  food: null,
  strength: null,
  cardio: null,
  step: null
});
const activityList = ref([])
const showActivityList = ref(false)
const showHealthTips = ref(false)
const selectedActivity = ref(null);
const selectedActivityId = ref(null);

const toggleActivityDetails = async (activityId) => {
    if (selectedActivityId.value === activityId) {
        selectedActivityId.value = null; // Zatvaramo detalje ako se klikne na istu aktivnost
        selectedActivity.value = null;
    } else {
        selectedActivityId.value = activityId;
        await fetchAndShowActivityDetails(activityId);
    }
};

const toggleActivityList = async (user_id) => {
  showActivityList.value = !showActivityList.value
  if (showActivityList.value) {
    await getUserActivities(user_id)
  }
}

const getHealthTips = async (user_id) => {
  try {
    const response = await axios.get(`http://localhost:8000/getHealthTips/${user_id}/`);
    healthTips.value = response.data.tips; 
  } catch (error) {
    console.error('Error fetching health tips:', error);
  }
};

const getTop3WaterConsumers = async (city) => {
  try {
    const response = await axios.get(`http://localhost:8000/top3WaterConsumers/${city}/`);
    top3WaterConsumers.value = response.data.data;
  } catch (error) {
    console.error('Error fetching health tips:', error);
  }
};

const deleteAccount = async (username, password) => {
  try {
    const response = await axios.delete('http://localhost:8000/deleteUser/', {
      data: {
        username,
        password
      }
    });
    console.log('Account successfully deleted:', response.data);
  } catch (error) {
    console.error('Error deleting account:', error);
  }
};

const promptForConfirmation = async () => {
  const enteredUsername = prompt('Enter your username:');
  if (enteredUsername === null) return;
  else {
    const enteredPassword = prompt('Enter your password:');
    if (enteredPassword === null) return;
    else {
      await deleteAccount(enteredUsername, enteredPassword);
    }
  }
};

const updateUserDetails = async (newValue, property, user_id) => {
  try {
    console.log(newValue, property, {[property]: parseInt(newValue)})
    const response = await axios.post('http://localhost:8000/setOptionalUserDetails/', {
      [property]: parseInt(newValue),
      user_details_id: user_id
    });
    console.log('Data updated successfully:', response.data);
  } catch (error) {
    console.error('Error updating data:', error);
  }
};

const getProductiveActivities = async (user_id) => {
  try {
    const response = await axios.get(`http://localhost:8000/getActivitiesAboveStepCount/${user_id}/10000/${offset.value}/${limit.value}/`);
    productiveActivities.value = response.data.activities;
  } catch (error) {
    console.error('Error fetching productive activities:', error);
  }
};

const prevPage = (user_id) => {
  if (offset.value >= limit.value) {
    offset.value -= limit.value;
    getProductiveActivities(user_id);
  }
};

const nextPage = (user_id) => {
  offset.value += limit.value;
  getProductiveActivities(user_id);
};

const createNewActivity = () => {
  showActivityForm.value = true;
};

const cancelNewActivity = () => {
  showActivityForm.value = false;
  resetNewActivity();
};

const resetNewActivity = () => {
  newActivity.value = {
    water: null,
    food: null,
    strength: null,
    cardio: null,
    step: null
  };
};

const submitNewActivity = async (user_id) => {
  try {
    const response = await axios.post('http://localhost:8000/addDailyActivity/', {
      ...newActivity.value,
      user_details_id: user_id
    });
    console.log('New activity created:', response.data);
    showActivityForm.value = false;
    resetNewActivity();
    getUserActivities(user_id);
    getHealthTips(user_id);
    getProductiveActivities(user_id);
  } catch (error) {
    console.error('Error creating new activity:', error);
  }
};

const getUserActivities = async (user_id) => {
  try {
    const response = await axios.get(`http://localhost:8000/getUserActivities/${user_id}/`);
    activityList.value = response.data.activity_list; 
  } catch (error) {
    console.error('Error fetching user activities:', error);
  }
};

const deleteActivityPrompt = (activityId, user_id) => {
  
  const confirmation = confirm('Are you sure you want to delete this activity?');
  if (confirmation) {
    deleteActivity(activityId, user_id);
  }
};

const deleteActivity = async (activityId, user_id) => {
  try {
    const response = await axios.delete('http://localhost:8000/deleteDailyActivity/', {
      data: {
        user_id: user_id,
        activity_id: activityId
      }
    });
    console.log('Activity successfully deleted:', response.data);
    await getUserActivities(user_id);
    await getProductiveActivities(user_id);
    await getHealthTips(user_id);
  } catch (error) {
    console.error('Error deleting activity:', error);
  }
};

const toggleHealthTips = async (user_id) => {
  showHealthTips.value = !showHealthTips.value;
  if (showHealthTips.value) {
    await getHealthTips(user_id);
  }
}

const fetchAndShowActivityDetails = async (activityId) => {
    try {
        const response = await axios.get(`http://localhost:8000/getActivityById/${activityId}/`);
        selectedActivity.value = response.data.activity;
    } catch (error) {
        console.error('Error fetching activity details:', error);
    }
};

const getFitPass = async (user_id) => {
    try {
        const response = await axios.post('http://localhost:8000/addFitPass/', {
          data : {user_details_id: user_id}
        });
        console.log('Fit pass successfully added:', response.data);
    } catch (error) {
        console.error('Error adding fit pass:', error);
    }
};

</script>

<template>
  <div>
    <h2>Hello, <span class="nameSpan">{{ userDetailsData.name }}</span></h2>
    <hr />
    <p><strong>User info:</strong></p>
    <p>Age: {{ userDetailsData.age }} y</p>
    <p>Weight:
      <span
        class="editableSpan"
        ref="editableSpanW"
        contenteditable
        @focusout="updateUserDetails($event.target.textContent.trim(), 'weight', userDetailsData.user_details_id)"
        @keydown.enter.prevent="updateUserDetails($event.target.textContent.trim(), 'weight', userDetailsData.user_details_id)"
      >{{ userDetailsData?.weight }}</span>kg
    </p>
    <p>Height:
      <span
        class="editableSpan"
        ref="editableSpanH"
        contenteditable
        @focusout="updateUserDetails($event.target.textContent.trim(), 'height', userDetailsData.user_details_id)"
        @keydown.enter.prevent="updateUserDetails($event.target.textContent.trim(), 'height', userDetailsData.user_details_id)"
      >{{ userDetailsData?.height }}</span>cm
    </p>
  </div>

  <hr />

  <div class="activityList">
    <button @click="toggleActivityList(userDetailsData.user_details_id)">Get all activities</button>
    <ol v-if="showActivityList">
        <li v-for="(activity, index) in activityList" :key="index">
            <span class="activity-li" @click="toggleActivityDetails(activity.activity_id)">
                Activity @{{ activity.date }}
            </span>
            <span @click="deleteActivityPrompt(activity.activity_id, userDetailsData.user_details_id)" class="x-button">X</span>
        </li>
    </ol>
    <p v-if="showActivityList && activityList.length === 0">No activities added currently.</p>
  </div>

  <ul v-if="selectedActivity && showActivityList">
    <li>Date: {{ selectedActivity.date }}</li>
    <li v-if="selectedActivity.water_in_ml">Water: {{ selectedActivity.water_in_ml }} ml</li>
    <li v-if="selectedActivity.food_in_kcal">Food: {{ selectedActivity.food_in_kcal }} kcal</li>
    <li v-if="selectedActivity.strength_training_in_min">Strength Training: {{ selectedActivity.strength_training_in_min }} min</li>
    <li v-if="selectedActivity.cardio_training_in_min">Cardio Training: {{ selectedActivity.cardio_training_in_min }} min</li>
    <li v-if="selectedActivity.step_count">Step Count: {{ selectedActivity.step_count }}</li>
  </ul>

  <hr />

  <div>
    <button @click="toggleHealthTips(userDetailsData.user_details_id)">Get health tips</button>
    <ul v-if="showHealthTips">
      <li v-for="(tip, index) in healthTips" :key="index">{{ tip }}</li>
    </ul>
  </div>

  <hr />

  <div class="newActivityForm">
      <button @click="createNewActivity(userDetailsData.user_details_id)">{{ showActivityForm ? 'Fill all fields with required data' : 'Create new daily activity' }}</button>
      <div v-if="showActivityForm" class="activity-form">
        <input placeholder="Water (ml)" type="number" v-model="newActivity.water" required>
        <input placeholder="Food (kcal)" type="number" v-model="newActivity.food" required>
        <input placeholder="Strenght training (min)" type="number" v-model="newActivity.strength" required>
        <input placeholder="Cardio training (min)" type="number" v-model="newActivity.cardio" required>
        <input placeholder="Step count" type="number" v-model="newActivity.step" required>
        <div class="activity-form-btns">
          <button @click="cancelNewActivity">Cancel</button>
          <button @click="submitNewActivity(userDetailsData.user_details_id)" class="post-button">Post</button>
        </div>
      </div>
  </div>

  <hr />

  <div class="productiveActivities">
    <button @click="getProductiveActivities(userDetailsData.user_details_id)">Get productive activities (above 10000 steps)</button>
    <ul>
      <li v-for="activity in productiveActivities" :key="activity.id">{{ activity.step_count }} steps @{{ activity.date }}</li>
    </ul>
    <div>
      <button @click="prevPage(userDetailsData.user_details_id)" :disabled="offset === 0" class="prevBtn">Previous Page</button>
      <button @click="nextPage(userDetailsData.user_details_id)" :disabled="productiveActivities.length < limit">Next Page</button>
    </div>
  </div>

  <hr />
  
  <div>
    <input class="rowInput" type="text" placeholder="City" autocomplete="off" v-model="city">
    <button @click="getTop3WaterConsumers(city)">Get top 3 water consumers</button>
    <ol>
      <li v-for="(person, index) in top3WaterConsumers" :key="index">{{ person.name }} ({{ person.water_consumpted }}ml)</li>
    </ol>
  </div>

  <hr />
    <div class="fitPassDiv">
      <button @click="getFitPass(userDetailsData.user_details_id)" class="fitBtn"><img src="../assets/flame.png">Get fit pass</button>
    </div>
  <hr />

    <div>
      <button @click="promptForConfirmation" class="dltBtn">Delete account permanently</button>
    </div>

</template>

<style scoped>
.editableSpan {
  padding: 0rem 0.2rem;
  cursor: pointer;
  color: #646cff
}

ul, ol {
  text-align: left;
}

.rowInput {
  margin-right: 0.5rem;
}

.productiveActivities {
  margin-bottom: 1rem;
}

.prevBtn {
  margin-right: 0.5rem;
}

.newActivityForm {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
  margin-bottom: 0.5rem;
}

.activity-form {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}
.activity-form-btns {
  display: flex;
  gap: 0.5rem;
  justify-content: flex-end;
}

.x-button {
  font-weight: 700;
  color: tomato;
  margin-left: 0.5rem;
  cursor: pointer;
}
.x-button:hover {
  color: rgb(179, 27, 0);
}
.post-button {
  color: #646cff;
}
.activityList {
  margin-bottom: 0.5rem;
}

hr {
  border-color: #646cff;
}

.dltBtn {
  color: tomato;
  margin-right: 0.5rem;
}

.nameSpan {
  color: #646cff;
}

p {
  text-align: left;
  line-height: 1rem;
}

.fitBtn {
  display: flex;
  justify-content: center;
  gap: 0.8rem;
  align-items: center;
}
.fitBtn img {
  width: 32px;
}

.fitPassDiv {
  display: flex;
  justify-content: center;
}

.activity-li:hover {
  cursor: pointer;
  color: #646cff;
}



</style>
