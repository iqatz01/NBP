<script setup>
import axios from 'axios'
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import Home from './Home.vue'


const router = useRouter()

const username = ref('')
const password = ref('')
const name = ref('')
const age = ref('')
const isLoginForm = ref(true)
const errorMessage = ref('')
const showHome = ref(false)
const isLoading = ref(false)
const userDetailsId = ref('')
const userDetailsData = ref('')
const showPassword = ref(false);

const togglePasswordVisibility = () => {
  showPassword.value = !showPassword.value;
};

const toggleForm = () => {
  isLoginForm.value = !isLoginForm.value
  errorMessage.value = ''

  if (isLoginForm.value) {
    router.push('/login')
  } else {
    router.push('/register')
  }
}

const attemptLogin = async () => {
  try {
    errorMessage.value = ''
    isLoading.value = true

    const response = await axios.post('http://localhost:8000/authenticateUser/', {
      username: username.value,
      password: password.value
    })

    await new Promise(resolve => setTimeout(resolve, 1000))
    
    if (response.data.status === 'success') {
      userDetailsId.value = response.data.user_details_id
      await getUserDetails()
      showHome.value = true
      router.push('/home')
    }
    else 
      errorMessage.value = response.data.message

  } catch (error) {
    console.error('Error during login:', error)
  } finally {
    isLoading.value = false
  }
}

const attemptRegister = async () => {
  try {
    errorMessage.value = ''
    isLoading.value = true

    const response = await axios.post('http://localhost:8000/registerUser/', {
      username: username.value,
      password: password.value,
      name: name.value,
      age: age.value
    })

    await new Promise(resolve => setTimeout(resolve, 1000))

    if (response.data.status === 'User registered successfully.') {
      isLoginForm.value = true
      password.value = ''
      name.value = ''
      age.value = ''
    }
    else 
      errorMessage.value = response.data.error

  } catch (error) {
    console.error('Error during login:', error)
  } finally {
    isLoading.value = false
  }
}

const getUserDetails = async () => {
  try {
    isLoading.value = true
    const response = await axios.get(`http://localhost:8000/getUserDetails/${userDetailsId.value}/`)
    console.log('User details:', response.data)
    
    userDetailsData.value = response.data

  } catch (error) {
    console.error('Error fetching user details:', error)
  } finally {
    isLoading.value = false
  }
}
</script>

<template>
  <div>
    <template v-if="!showHome">
      <h1>FitnessApp</h1>

      <div class="auth-form">
        <input type="text" placeholder="Username" autocomplete="off" v-model="username">
        <div class="pw-input">
          <input :type="showPassword ? 'text' : 'password'" placeholder="Password" autocomplete="off" v-model="password">
          <span @mousedown="togglePasswordVisibility" @mouseup="togglePasswordVisibility" class="eye-span">
            <img v-if="!showPassword"  src="../assets/view.png" alt="Show password" class="eye-img">
            <img v-if="showPassword"  src="../assets/hidden.png" alt="Show password" class="eye-img">
          </span>
        </div>
        <input type="text" placeholder="Name" autocomplete="off" v-model="name" v-if="!isLoginForm">
        <input type="text" placeholder="Age" autocomplete="off" v-model="age" v-if="!isLoginForm">
        <button type="button" @click="isLoginForm ? attemptLogin() : attemptRegister()" :disabled="isLoading">
          <img v-if="isLoading" class="spinner" src="../assets/spinner.svg" alt="Loading">
          <span v-else>{{ isLoginForm ? 'Login' : 'Register' }}</span>
        </button>
        <div v-if="errorMessage" class="error-message">{{ errorMessage }}</div>
        <span class="register-link" @click="toggleForm" v-if="isLoginForm">
          Don't have an account? Register
        </span>
        <span class="register-link" @click="toggleForm" v-else>
          Already have an account? Login
        </span>
      </div>
    </template>
    <Home :userDetailsData="userDetailsData" v-else />
  </div>
</template>

<style scoped>
.auth-form {
  display: flex;
  flex-direction: column;
  gap: 0.6rem;
}
.register-link {
  color: #646cff; 
  cursor: pointer;
  transition: color 0.3s;
}
.register-link:hover {
  color: #535bf2;
}
.error-message {
  color: tomato;
}

.eye-img {
  cursor: pointer; 
  width: 20px; 
  height: 20px;
  fill: #646cff;
  filter: invert(1);
}

.eye-span {
  position: absolute;
  right: 5%; 
  top: 50%; 
  transform: translateY(-40%);
  
}
.pw-input {
  text-align: center;
  position: relative;
}
.pw-input input {
  width: 90%;
}

</style>
