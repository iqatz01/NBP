from django.apps import AppConfig


class Neo4JdjangoappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'neo4jdjangoapp'
