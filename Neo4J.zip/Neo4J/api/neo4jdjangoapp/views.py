from django.shortcuts import render

from django.http import JsonResponse
from neo4j import GraphDatabase, basic_auth
from django.conf import settings

def execute_neo4j_query(query, parameters=None, fetch=False):
    neo4j_settings = settings.NEO4J_DATABASES['default']
    uri = f"neo4j://{neo4j_settings['HOST']}:{neo4j_settings['PORT']}"
    auth = basic_auth(neo4j_settings['USER'], neo4j_settings['PASSWORD'])

    with GraphDatabase.driver(uri, auth=auth) as driver:
        with driver.session(database='neo4j') as session:
            result = session.run(query, parameters)

            if fetch:
                # Koristite iteraciju nad Result objektom
                return list(result)

    return None

def create_user(request, username):
    # Dodaj korisnika
    query = "MERGE (u:User {username: $username})"
    parameters = {"username": username}
    execute_neo4j_query(query, parameters)
    return JsonResponse({"status": "Korisnik " + username + " dodat!"})

def add_interest(request, username, interest):
    # Dodaj interes
    query = (
        "MERGE (u:User {username: $username}) "
        "MERGE (i:Interest {interest: $interest}) "
        "MERGE (u)-[:INTERESTED_FOR]->(i)"
    )
    parameters = {"username": username, "interest": interest}
    execute_neo4j_query(query, parameters)
    return JsonResponse({"status": "Interes " + interest + " dodat korisniku " + interest + "!"})

def add_friend(request, username, friend_username):
    # Dodaj prijatelja
    query = (
        "MERGE (u:User {username: $username}) "
        "MERGE (friend:User {username: $friend_username}) "
        "MERGE (u)-[:FOLLOWS]->(friend)"
    )
    parameters = {"username": username, "friend_username": friend_username}
    execute_neo4j_query(query, parameters)

    return JsonResponse({"status": "Prijatelj dodat!"})

def get_interests(request, username):
    query = (
        "MATCH (u:User {username: $username})-[:INTERESTED_FOR]->(interest) "
        "RETURN interest.interest ORDER BY interest.interest"
    )
    parameters = {"username": username}
    records = execute_neo4j_query(query, parameters, fetch=True)
    interests = [record["interest.interest"] for record in records]
    return JsonResponse({"interests": interests})

def get_friends(request, username):
    query = (
        "MATCH (u:User {username: $username})-[:FOLLOWS]->(friend) "
        "RETURN friend.username ORDER BY friend.username"
    )
    parameters = {"username": username}
    records = execute_neo4j_query(query, parameters, fetch=True)
    friends = [record["friend.username"] for record in records]
    return JsonResponse({"friends": friends})

def remove_interest(request, username, interest):
    # Ukloni vezu između User i Interest
    query = (
        "MATCH (u:User {username: $username})-[r:INTERESTED_FOR]->(interest:Interest {interest: $interest}) "
        "DELETE r"
    )
    parameters = {"username": username, "interest": interest}
    execute_neo4j_query(query, parameters)
    return JsonResponse({"status": "Veza između User-a " + username + " i Interesa " + interest + " je uklonjena!"})

def remove_friend(request, username, friend_username):
    # Ukloni vezu između User i Friend
    query = (
        "MATCH (u:User {username: $username})-[r:FOLLOWS]->(friend:User {username: $friend_username}) "
        "DELETE r"
    )
    parameters = {"username": username, "friend_username": friend_username}
    execute_neo4j_query(query, parameters)
    return JsonResponse({"status": "Veza između User-a i Prijatelja uklonjena!"})

def change_username(request, username, new_username):
    query = "MATCH (u:User {username: $username}) SET u.username = $new_username"
    parameters = {"username": username, "new_username": new_username}
    execute_neo4j_query(query, parameters)
    return JsonResponse({"status": "Username promijenjen u " + new_username + "!"})

def get_friend_recommendation(request, username):
    # Dohvati interese trenutnog korisnika
    interests_query = (
        "MATCH (u:User {username: $username})-[:INTERESTED_FOR]->(interest) "
        "RETURN interest.interest"
    )
    interests_parameters = {"username": username}
    user_interests_records = execute_neo4j_query(interests_query, interests_parameters, fetch=True)
    user_interests = [record["interest.interest"] for record in user_interests_records]

    # Dohvati korisnike koji imaju zajedničke interese s trenutnim korisnikom, ali nisu prijatelji
    recommendation_query = (
        "MATCH (u:User {username: $username})-[:INTERESTED_FOR]->(interest)<-[:INTERESTED_FOR]-(other:User) "
        "WHERE NOT (u)-[:FOLLOWS]->(other) AND other.username <> $username "
        "RETURN DISTINCT other.username"
    )
    recommendation_parameters = {"username": username}
    recommendation_records = execute_neo4j_query(recommendation_query, recommendation_parameters, fetch=True)
    recommendations = [record["other.username"] for record in recommendation_records]

    return JsonResponse({"recommendations": recommendations})

def delete_user(request, username):
    # Obriši korisnički čvor i sve veze ka ostalim čvorovima
    query = (
        "MATCH (u:User {username: $username}) "
        "DETACH DELETE u"
    )
    parameters = {"username": username}
    execute_neo4j_query(query, parameters)
    
    return JsonResponse({"status": f"Korisnik {username} obrisan zajedno sa svim vezama."})