"""
URL configuration for neo4jdjangoproject project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.urls import path
from neo4jdjangoapp.views import create_user, add_interest, add_friend, get_interests, get_friends, remove_interest, remove_friend, change_username, get_friend_recommendation, delete_user

urlpatterns = [
    path('create_user/<str:username>/', create_user, name='create_user'),
    path('add_interest/<str:username>/<str:interest>/', add_interest, name='add_interest'),
    path('add_friend/<str:username>/<str:friend_username>/', add_friend, name='add_friend'),
    path('get_interests/<str:username>/', get_interests, name='get_interests'),
    path('get_friends/<str:username>/', get_friends, name='get_friends'),
    path('remove_interest/<str:username>/<str:interest>/', remove_interest, name='remove_interest'),
    path('remove_friend/<str:username>/<str:friend_username>/', remove_friend, name='remove_friend'),
    path('change_username/<str:username>/<str:new_username>/', change_username, name='change_username'),
    path('get_friend_recommendation/<str:username>/', get_friend_recommendation, name='get_friend_recommendation'),
    path('delete_user/<str:username>/', delete_user, name='delete_user'),
]
