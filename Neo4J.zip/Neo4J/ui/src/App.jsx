import { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const inputRef = useRef(null);
  const interestRef = useRef(null);
  const friendRef = useRef(null);
  const usernameRef = useRef()
  const [username, setUsername] = useState(null);
  const [interests, setInterests] = useState([]);
  const [friends, setFriends] = useState([]);
  const [recommendedFriends, setRecommendedFriends] = useState([]);
  const [showRecommendedFriends, setShowRecommendedFriends] = useState(false);

  const handleLogin = async () => {
    const inputValue = inputRef.current.value;
    setUsername(inputValue); 
    try {
      await axios.post(`http://localhost:8000/create_user/${inputValue}/`);
      await fetchInterests(inputValue);
      await fetchFriends(inputValue);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const fetchInterests = async (user) => {
    try {
      setInterests((await axios.get(`http://localhost:8000/get_interests/${user}/`)).data.interests);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }

  const fetchFriends = async (user) => {
    try {
      setFriends((await axios.get(`http://localhost:8000/get_friends/${user}/`)).data.friends);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }

  

  const handleAddInterest = async () => {
    const interestValue = interestRef.current.value;
    try {
      const response = await axios.post(`http://localhost:8000/add_interest/${username}/${interestValue}/`);
      console.log('New interest added to user: ' + username);
      await fetchInterests(username);
      if (showRecommendedFriends) await getRecommendedFriends();
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const removeInterest = async (interest) => {
    try {
      await axios.delete(`http://localhost:8000/remove_interest/${username}/${interest}/`);
      await fetchInterests(username);
      await getRecommendedFriends();
      if (showRecommendedFriends) await getRecommendedFriends();
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }

  const handleAddFriend = async (friend) => {
    
    try {
      const response = await axios.post(`http://localhost:8000/add_friend/${username}/${friend}/`);
      console.log('New friend added to user: ' + username );
      await fetchFriends(username);
      if (showRecommendedFriends) await getRecommendedFriends();
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const removeFriend = async (friend) => {
    try {
      await axios.delete(`http://localhost:8000/remove_friend/${username}/${friend}/`);
      await fetchFriends(username);
      if (showRecommendedFriends) await getRecommendedFriends();
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }

  const changeUsername = async () => {
    
    try {
      const newUsername = usernameRef.current.value;
      setUsername(newUsername);
      await axios.put(`http://localhost:8000/change_username/${username}/${newUsername}/`);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  const getRecommendedFriends = async () => {
    
    try {
      setShowRecommendedFriends(true);
      setRecommendedFriends((await axios.put(`http://localhost:8000/get_friend_recommendation/${username}/`)).data.recommendations);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }

  const handleDeleteAccount = async () => {
    try {
      await axios.delete(`http://localhost:8000/delete_user/${username}/`);
      setUsername(null);
      setInterests([]);
      setFriends([]);
      setRecommendedFriends([]);
      setShowRecommendedFriends(false);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }

  const handleLogout = () => {
    try {
      setUsername(null);
      setInterests([]);
      setFriends([]);
      setRecommendedFriends([]);
      setShowRecommendedFriends(false);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  }


  return (
    <>
 
        
    {!username ? (
        <div className='login-div'>
          <div className='login-div-input'>
            <p>Username</p>
            <input type='text' placeholder='Enter username' ref={inputRef} />
          </div>
          <button onClick={handleLogin}>Log in</button>
        </div>
      ) : (
        // Prikaži trenutno ime ako je name definisan
        <>
         <p>Logged in</p>
         <p>Username: <input type="text" defaultValue={username} ref={usernameRef} /></p>
         <button onClick={changeUsername}>Change username</button>
         <div className='div-input'>
              <p>Interest</p>
              <input type='text' placeholder='Enter interest' ref={interestRef} />
            </div>
            <button onClick={handleAddInterest}>Add new interest</button>
            <div className='list'>
            { interests.length ? <p>Your interests:</p> : null }
            <ol>
              {interests.map((interest) => <li key={interest}>{interest} <button className='button-x' onClick={() => removeInterest(interest)}>Remove</button></li>)}
            </ol>
         </div>
            <div className='div-input'>
              <p>Friend</p>
              <input type='text' placeholder={`Enter friend's username`} ref={friendRef} />
            </div>
            <button onClick={() => handleAddFriend(friendRef.current.value)}>Add new friend</button>
         <div className='list'>
         { friends.length ? <p>Your friends:</p> : null }
         
            <ol>
              {friends.map((friend) => <li key={friend}>{friend} <button className='button-x' onClick={() => removeFriend(friend)}>Remove</button></li>)}
            </ol>
         </div>
         <button onClick={getRecommendedFriends}>Get new friend recommendations</button>
         <div className='list'>
         { recommendedFriends.length ?  <p>Recommended friends:</p> : null }
            <ol>
              {showRecommendedFriends ? recommendedFriends.map((friend) => <li key={friend}>{friend} <button className='button-x' onClick={() => handleAddFriend(friend)}>Add</button></li>) : null}
            </ol>
         </div>
         <button className='delete-acc-button' onClick={handleDeleteAccount}>Delete account permanently</button>
         <button className='logout-button' onClick={handleLogout}>Log out</button>
        </>
      )}


     
    </>
  )
}

export default App
